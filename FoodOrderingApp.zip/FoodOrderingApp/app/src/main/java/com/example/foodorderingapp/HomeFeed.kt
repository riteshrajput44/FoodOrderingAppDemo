package com.example.foodorderingapp

class HomeFeed (val list:List<resdata>)