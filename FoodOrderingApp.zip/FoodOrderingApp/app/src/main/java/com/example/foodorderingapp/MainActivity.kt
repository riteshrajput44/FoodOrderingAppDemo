package com.example.foodorderingapp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.room.Room
import com.example.foodorderingapp.databinding.ActivityMainBinding
import com.example.foodorderingapp.util.NetworkManager



class MainActivity : AppCompatActivity() {

    lateinit var imgsplash: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        val view: View = binding.root
        val network = NetworkManager()
        val net = network.checkConnectivity(this)
        setContentView(view)
        imgsplash = findViewById(R.id.imgburgericonsplash)
        imgsplash.visibility = View.VISIBLE

        val animation = AnimationUtils.loadAnimation(this, R.anim.fade_in)

        imgsplash.startAnimation(animation)

        val pref: SharedPreferences = getSharedPreferences("login", MODE_PRIVATE)


        try {
            this.supportActionBar!!.hide()
        } catch (e: NullPointerException) {
        }

        val loginactivity = LoginActivity()
        val home = ProfileActivity()

        if (!pref.getBoolean("login", false)) {
            Handler().postDelayed({
                val inti = Intent(this, LoginActivity::class.java)
                startActivity(inti)
                finish()
            }, 2000)
        } else {
            Handler().postDelayed({
                val inti =Intent(this,MainPage::class.java)
                startActivity(inti)
                finish()
            }, 2000)
        }
    }


}

