package com.example.foodorderingapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray

class AdaptorChildOrder(val context: Context , val arraylsit :JSONArray):RecyclerView.Adapter<AdaptorChildOrder.MyHolder>() {
    class MyHolder(view: View):RecyclerView.ViewHolder(view){
        val dishname:TextView = view.findViewById(R.id.dishanamechildrv)
        val costone:TextView = view.findViewById(R.id.priceofonedish)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.child_rv_design,parent,false)
        return MyHolder(view)
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        holder.dishname.text =arraylsit.getJSONObject(position).getString("name")
        holder.costone.text=arraylsit.getJSONObject(position).getString("cost")
    }

    override fun getItemCount(): Int {
        return arraylsit.length()
    }
}