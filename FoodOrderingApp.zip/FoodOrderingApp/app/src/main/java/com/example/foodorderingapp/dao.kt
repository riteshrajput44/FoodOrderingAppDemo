package com.example.foodorderingapp

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface dao {
    @Insert
    fun insertfav(dbhelper: dbhelper)
    @Delete
    fun deletefav(dbhelper: dbhelper)
    @Query("SELECT EXISTS(SELECT * FROM dbhelper WHERE name=:name)")
    fun checkExists(name:String):Boolean

}