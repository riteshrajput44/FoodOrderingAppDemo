package com.example.foodorderingapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject

class AdaptorParentOrder(val context: Context,val arrayList: JSONArray):RecyclerView.Adapter<AdaptorParentOrder.MyHolder>() {
    class MyHolder(view:View):RecyclerView.ViewHolder(view){
        val childView:RecyclerView = view.findViewById(R.id.child_rv_order)
        val nameres:TextView = view.findViewById(R.id.nameresorderhis)
        val date:TextView =view.findViewById(R.id.dateorder)
        val totalprice:TextView = view.findViewById(R.id.totalprice_parentrv)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.parent_order_rv,parent,false)
        return AdaptorParentOrder.MyHolder(view)
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        val adaptorchild =AdaptorChildOrder(context,arrayList.getJSONObject(position).getJSONArray("food_items"))
        val layoutmanager =LinearLayoutManager(context)
        holder.childView.layoutManager = layoutmanager
        holder.childView.adapter = adaptorchild
        holder.nameres.text = arrayList.getJSONObject(position).getString("restaurant_name")
        holder.date.text = arrayList.getJSONObject(position).getString("order_placed_at")
        holder.totalprice.text = arrayList.getJSONObject(position).getString("total_cost")


    }

    override fun getItemCount(): Int {
        return arrayList.length()
    }
}