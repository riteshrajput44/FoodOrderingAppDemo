package com.example.foodorderingapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.ViewTreeObserver
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.databinding.ActivityRestrurantBinding
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONArray
import org.json.JSONObject

class RestrurantActivity : AppCompatActivity() {
    lateinit var recyclerfood: RecyclerView
    lateinit var layoutmanager: RecyclerView.LayoutManager
    lateinit var adaptorFood: AdaptorFood

    companion object {
        @SuppressLint("StaticFieldLeak")
        lateinit var binding: ActivityRestrurantBinding
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRestrurantBinding.inflate(layoutInflater)
        val view: View = binding.root
        val view1: View = binding.foodlist
        setContentView(view)
        val network = NetworkManager()
        val net = network.checkConnectivity(this)
        var arrayList = ArrayList<JSONObject>()
        if (intent.hasExtra("res_id") && net) {
            intent.getStringExtra("name")?.let { setUpToolBar(binding.toolbarrestrurant, it) }
            val url =
                "http://13.235.250.119/v2/restaurants/fetch_result/${intent.getStringExtra("res_id")}"
            val queue = Volley.newRequestQueue(this)
            val jsonreq = object : JsonObjectRequest(Request.Method.GET, url, null,
                Response.Listener {

                    if (it.getJSONObject("data").getBoolean("success")) {
                        var jsonArray = JSONArray()
                        jsonArray = it.getJSONObject("data").getJSONArray("data")
                        for (i in 0..(it.getJSONObject("data").getJSONArray("data").length() - 1)) {
                            arrayList.add(jsonArray.getJSONObject(i))
                        }
                        recyclerfood = view.findViewById(R.id.foodlist)
                        layoutmanager = LinearLayoutManager(this)
                        adaptorFood = AdaptorFood(this as Context, arrayList)
                        recyclerfood.adapter = adaptorFood
                        recyclerfood.layoutManager = layoutmanager
                    }
                }, Response.ErrorListener {

                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    headers["token"] = "93ff4ed315f7e3"
                    return headers
                }
            }
            queue.add(jsonreq)

            binding.btnplaceorder.setOnClickListener {
                val inti = Intent(this, OrderSummaryActivity::class.java)
                inti.putExtra("id", intent.getStringExtra("res_id"))
                startActivity(inti)
                finish()
            }
        } else {
            Toast.makeText(this, "No Connection", Toast.LENGTH_SHORT).show()
            setUpToolBar(binding.toolbarrestrurant, "Default")
        }


    }

    private fun setUpToolBar(toolbar: Toolbar, string: String) {
        setSupportActionBar(toolbar)
        supportActionBar?.title = string
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onBackPressed() {
        val db = Room.databaseBuilder(this,dborderdatabase::class.java,"dborder").allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao = db.orderDao()
        dao.deleteall()
        super.onBackPressed()
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            android.R.id.home -> {
                val inti = Intent(this , MainPage::class.java)
                startActivity(inti)
                finish()
            }
        }
        return super.onContextItemSelected(item)
    }

}

