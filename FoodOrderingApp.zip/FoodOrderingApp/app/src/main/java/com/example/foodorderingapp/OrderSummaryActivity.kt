package com.example.foodorderingapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.RestrurantActivity.Companion.binding
import com.example.foodorderingapp.databinding.ActivityOrderSummaryBinding
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONArray
import org.json.JSONObject

class OrderSummaryActivity : AppCompatActivity() {
    lateinit var recyclerorder: RecyclerView
    lateinit var layoutmanager: RecyclerView.LayoutManager
    lateinit var adaptororder: AdaptorOrderNow

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityOrderSummaryBinding.inflate(layoutInflater)
        val view: View = binding.root
        setContentView(view)
        setUpToolBar(binding.toolbarordernow ,"Order Summary")
        val network = NetworkManager()
        val net = network.checkConnectivity(this)
        if (net) {
            val db = Room.databaseBuilder(this, dborderdatabase::class.java, "dborder")
                .allowMainThreadQueries().fallbackToDestructiveMigration().build()
            val dao = db.orderDao()
            val s = dao.selectALl()
            val list = ArrayList<List<String>>()
            var totalcost = 0
            val jsonArray = JSONArray()
            for (i in s) {
                val templist = i.split(",")
                val tempjsonobj = JSONObject()
                tempjsonobj.put("food_item_id", templist[0])
                jsonArray.put(tempjsonobj)
                list.add(templist)
                totalcost = templist[1].toInt() + totalcost
            }
            binding.btnplaceorderordernow.text = "Total Price is Rs(${totalcost})"
            recyclerorder = view.findViewById(R.id.orderlist)
            layoutmanager = LinearLayoutManager(this)
            adaptororder = AdaptorOrderNow(this, list)
            recyclerorder.adapter = adaptororder
            recyclerorder.layoutManager = layoutmanager
            val pref = getSharedPreferences("login", MODE_PRIVATE)
            var jsonObject = JSONObject()
            jsonObject.put("user_id", pref.getString("user_id", ""))
            jsonObject.put("restaurant_id", intent.getStringExtra("id"))
            jsonObject.put("total_cost", totalcost.toString())
            jsonObject.put("food", jsonArray)

            binding.btnplaceorderordernow.setOnClickListener {
                val url = "http://13.235.250.119/v2/place_order/fetch_result/"
                val queue = Volley.newRequestQueue(this)
                val jsonReq = object : JsonObjectRequest(
                    Request.Method.POST,
                    url,
                    jsonObject,
                    Response.Listener {
                        if (it.getJSONObject("data").getBoolean("success")) {
                            Toast.makeText(this, "Ok success", Toast.LENGTH_SHORT).show()
                            val inti = Intent(this , CongratualtionActivity::class.java)
                            startActivity(inti)
                            finish()
                        }
                    },
                    Response.ErrorListener { }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-Type"] = "application/json"
                        headers["token"] = "93ff4ed315f7e3"
                        return headers
                    }
                }
                queue.add(jsonReq)
            }
        } else {
            Toast.makeText(this, "Check Connection", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        val db = Room.databaseBuilder(this, dborderdatabase::class.java, "dborder")
            .allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao = db.orderDao()
        dao.deleteall()
        super.onDestroy()
    }
    private fun setUpToolBar(toolbar: Toolbar, string: String) {
        setSupportActionBar(toolbar)
        supportActionBar?.title = string
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onBackPressed() {
        val db = Room.databaseBuilder(this, dborderdatabase::class.java, "dborder")
            .allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao = db.orderDao()
        dao.deleteall()
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            android.R.id.home -> {
                val inti = Intent(this , MainPage::class.java)
                startActivity(inti)
                finish()
            }
        }
        return super.onContextItemSelected(item)
    }
}
