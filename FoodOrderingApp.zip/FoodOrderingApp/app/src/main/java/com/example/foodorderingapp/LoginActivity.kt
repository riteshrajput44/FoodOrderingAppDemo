package com.example.foodorderingapp

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Header
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.databinding.ActivityLoginBinding
import com.example.foodorderingapp.util.NetworkConnection
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var binding:ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        val network =NetworkManager()
        val checkNetwork = NetworkManager()
        setContentView(view)


        binding.btnregnow.setOnClickListener{
            if(checkNetwork.checkConnectivity(this)){
            val inti = Intent(this,RegisterActivity::class.java)
            startActivity(inti)
            finish()}
            else{
                Toast.makeText(this,"Check Your Network",Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnlogin.setOnClickListener {if(network.checkConnectivity(this)){
            val queue = Volley.newRequestQueue(this)
            val url = "http://13.235.250.119/v2/login/fetch_result"
            val jasonParams = JSONObject()

            jasonParams.put("mobile_number",binding.logUsername.text.toString())
            jasonParams.put("password",binding.logPwd.text.toString())

            if(binding.logUsername.text.toString().length ==10 && binding.logPwd.text.toString().length>= 6){
                val jasonreq = object :JsonObjectRequest(Request.Method.POST,url,jasonParams,
                    Response.Listener {
                                      try {
                                          val success = it.getJSONObject("data").getBoolean("success")
                                          if(success){
                                              val pref :SharedPreferences = getSharedPreferences("login",
                                                  MODE_PRIVATE)
                                              val editor :SharedPreferences.Editor=pref.edit()
                                              editor.putString("user_id",it.getJSONObject("data").getJSONObject("data").getString("user_id"))
                                              editor.putString("name",it.getJSONObject("data").getJSONObject("data").getString("name"))
                                              editor.putString("email",it.getJSONObject("data").getJSONObject("data").getString("email"))
                                              editor.putString("mobile_number",it.getJSONObject("data").getJSONObject("data").getString("mobile_number"))
                                              editor.putString("address",it.getJSONObject("data").getJSONObject("data").getString("address"))
                                              editor.putBoolean("login",true)
                                              editor.apply()
                                              val inti =Intent(this,MainPage::class.java)
                                              startActivity(inti)
                                              finish()
                                          }
                                          else{
                                              Toast.makeText(this,"Z $it",Toast.LENGTH_SHORT).show()
                                          }
                                      }catch (e:Exception){
                                          Toast.makeText(this,"Y $it",Toast.LENGTH_SHORT).show()
                                      }

                },Response.ErrorListener {
                        Toast.makeText(this,"R $it",Toast.LENGTH_SHORT).show()
                }){
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String,String>()
                        headers["Content-Type"]= "application/json"
                        headers["token"] = "93ff4ed315f7e3"
                        return headers
                    }
                }
                queue.add(jasonreq)
            }}
            else   {
                Toast.makeText(this,"Check Network",Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnforgotpwdlogin.setOnClickListener {
            if(network.checkConnectivity(this)){
            val inti = Intent(this,ForgotPwdActivity::class.java)
            startActivity(inti)
            finish()}
            else{Toast.makeText(this,"Check Network",Toast.LENGTH_SHORT).show()}
        }



    }


}
