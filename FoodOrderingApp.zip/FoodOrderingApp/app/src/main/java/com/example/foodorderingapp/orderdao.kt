package com.example.foodorderingapp

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface orderdao {
    @Insert
    fun insertid(dborder: dborder)

    @Delete
    fun deleteid(dborder: dborder)

    @Query("SELECT EXISTS(SELECT * FROM dnorder WHERE id=:id)")
    fun exists(id:String):Boolean

    @Query("SELECT count(*) FROM dnorder")
    fun count():Int

    @Query("DELETE FROM dnorder")
    fun deleteall()

    @Query("SELECT * FROM dnorder")
    fun alldata():dborder

    @Query("SELECT id||','||cost||','||res_id||','||name FROM dnorder")
    fun selectALl():List<String>
}