package com.example.foodorderingapp

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import org.json.JSONObject

class AdaptorFood(val context: Context,val arrayList: ArrayList<JSONObject>) :RecyclerView.Adapter<AdaptorFood.MyHolder>(){
    class MyHolder(view: View):RecyclerView.ViewHolder(view){
        val layoutclick: RelativeLayout =view.findViewById(R.id.card_food)
        val name: TextView =view.findViewById(R.id.dishname)
        val cost: TextView =view.findViewById(R.id.costitem)
        val order: Button =view.findViewById(R.id.addbtnorder)
        val number:TextView =view.findViewById(R.id.number)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recyclerfooitem,parent,false)
        return AdaptorFood.MyHolder(view)
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        holder.name.text = arrayList[position].getString("name")
        holder.cost.text = arrayList[position].getString("cost_for_one")
        holder.number.text = position.toString()
        val db = Room.databaseBuilder(context,dborderdatabase::class.java,"dborder").allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao = db.orderDao()
        RestrurantActivity.binding.btnplaceorder.visibility=View.GONE
        holder.order.setOnClickListener {
            val data = dborder(arrayList[position].getString("id"),arrayList[position].getString("cost_for_one"),arrayList[position].getString("restaurant_id"),arrayList[position].getString("name"))
            if (dao.exists(arrayList[position].getString("id"))){
                dao.deleteid(data)
                holder.order.text = "Add"
                holder.order.setBackgroundResource(com.google.android.material.R.color.mtrl_btn_transparent_bg_color)
                holder.order.setTextColor(Color.BLACK)
            }
            else{
                dao.insertid(data)
                holder.order.text = "Remove"
                holder.order.setBackgroundColor(Color.RED)
                holder.order.setTextColor(Color.WHITE)
            }
            if (dao.count() == 0){
                RestrurantActivity.binding.btnplaceorder.visibility=View.GONE
            }
            else{
                RestrurantActivity.binding.btnplaceorder.visibility=View.VISIBLE
            }
        }
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }
}