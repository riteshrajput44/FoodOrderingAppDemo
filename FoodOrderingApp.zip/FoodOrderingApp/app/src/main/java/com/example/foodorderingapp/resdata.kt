package com.example.foodorderingapp

data class resdata (val id:String ,val name:String,val rating:Float,val cost_for_one:Int,val img_url:String)