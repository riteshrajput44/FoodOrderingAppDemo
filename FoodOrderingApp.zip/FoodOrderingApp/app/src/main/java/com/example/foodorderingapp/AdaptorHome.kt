package com.example.foodorderingapp

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.squareup.picasso.Picasso
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL


class AdaptorHome(val context: Context,val arrayList: MutableList<resdata>):RecyclerView.Adapter<AdaptorHome.MyHolder>() {

    class MyHolder(view: View ) : RecyclerView.ViewHolder(view) {
        val layoutclick:RelativeLayout=view.findViewById(R.id.cardlayout)
        val name:TextView=view.findViewById(R.id.resturantname)
        val cost:TextView =view.findViewById(R.id.costoneperson)
        val rating:TextView=view.findViewById(R.id.ratingedit)
        val img:ImageView = view.findViewById(R.id.imgautogen)
        val fav:ImageButton=view.findViewById(R.id.btnfavclick)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.card_view,parent,false)
        return MyHolder(view)
    }



    override fun getItemCount(): Int {
        return arrayList.size
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        Picasso.get().load(arrayList[position].img_url).into(holder.img)
        holder.name.text = arrayList[position].name
        holder.cost.text = arrayList[position].cost_for_one.toString()
        holder.rating.text = arrayList[position].rating.toString()
        holder.layoutclick.setOnClickListener{
            val inti = Intent(context,RestrurantActivity::class.java)
            inti.putExtra("res_id",arrayList[position].id)
            inti.putExtra("name",arrayList[position].name)
            context.startActivity(inti)
            Toast.makeText(context,"${arrayList[position].name}",Toast.LENGTH_SHORT).show()
        }
        val db = Room.databaseBuilder(context,favdatabase::class.java,"dbhelper").allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao =db.favdao()
        val new = dbhelper(arrayList[position].name)
        if (dao.checkExists(arrayList[position].name)){
            holder.fav.setImageResource(R.drawable.favorite)
        }
        else{
            holder.fav.setImageResource(R.drawable.ic_baseline_favorite_border_24)
        }

        holder.fav.setOnClickListener {
            val db = Room.databaseBuilder(context,favdatabase::class.java,"dbhelper").allowMainThreadQueries().fallbackToDestructiveMigration().build()
            val dao =db.favdao()
            val new = dbhelper(arrayList[position].name)
            if (dao.checkExists(arrayList[position].name)){
                holder.fav.setImageResource(R.drawable.ic_baseline_favorite_border_24)
                dao.deletefav(new)
                Toast.makeText(context,"Deleted ${arrayList[position].name} from Favorites",Toast.LENGTH_SHORT).show()
            }
            else{
                holder.fav.setImageResource(R.drawable.favorite)
                dao.insertfav(new)
                Toast.makeText(context,"Added ${arrayList[position].name} from Favorites",Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun getBitmapFromURL(src: String): Bitmap? {
        return try {
            Log.e("src", src)
            val url = URL(src)
            val connection: HttpURLConnection = url.openConnection() as HttpURLConnection
            connection.setDoInput(true)
            connection.connect()
            val input: InputStream = connection.getInputStream()
            val myBitmap = BitmapFactory.decodeStream(input)
            Log.e("Bitmap", "returned")
            myBitmap
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
}


