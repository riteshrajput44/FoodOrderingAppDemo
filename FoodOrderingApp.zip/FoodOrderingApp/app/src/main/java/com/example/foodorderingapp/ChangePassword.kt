package com.example.foodorderingapp

import android.os.Build.VERSION_CODES.N
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.example.foodorderingapp.databinding.ActivityChangePasswordBinding
import com.example.foodorderingapp.databinding.ActivityForgotPwdBinding
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONObject

class ChangePassword : AppCompatActivity() {
    lateinit var binding: ActivityChangePasswordBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        val view: View = binding.root
        val network = NetworkManager()
        val net = network.checkConnectivity(this)
        setContentView(view)

        binding.changepwdbtn.setOnClickListener {
            if (net) {
                val url = "http://13.235.250.119/v2/reset_password/fetch_result"
                val jasonObj = JSONObject()
                jasonObj.put("mobile_number", binding.changemobileno.text.toString())
                jasonObj.put("password", binding.passwordchnage.text.toString())
                jasonObj.put("otp", binding.otp.text.toString())
                if (binding.changemobileno.text.toString().length == 10) {
                    val json = object : JsonObjectRequest(Request.Method.POST, url, jasonObj,
                        Response.Listener {
                            try {
                                val success = it.getJSONObject("data").getBoolean("success")
                                if (success) {
                                } else {
                                }
                            } catch (e: Exception) {
                            }
                        }, Response.ErrorListener { }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Content-Type"] = "application/json"
                            headers["token"] = "93ff4ed315f7e3"
                            return headers
                        }
                    }

                } else {
                    Toast.makeText(this, "Check Network", Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
}
