package com.example.foodorderingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RestrurantList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restrurant_list)
    }
}