package com.example.foodorderingapp

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.R
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONArray
import org.json.JSONObject


class FavioratesFragment : Fragment() {
    lateinit var adaptorrest:AdaptorHome
    lateinit var recyclerHome: RecyclerView
    lateinit var layoutmanager: RecyclerView.LayoutManager
    lateinit var listRestrurant:ArrayList<JSONObject>
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view:View = inflater.inflate(R.layout.fragment_faviorates, container, false)
        val network = NetworkManager()
        val net =network.checkConnectivity(view.context)
        listRestrurant=ArrayList<JSONObject>()
        if (net){
            val queue = Volley.newRequestQueue(activity as Context)
            val url = "http://13.235.250.119/v2/restaurants/fetch_result/"
            val jasonreq = object : JsonObjectRequest(Request.Method.GET,url,null, Response.Listener {
                if (it.getJSONObject("data").getBoolean("success")){
                    val childarray: JSONArray = it.getJSONObject("data").getJSONArray("data")
                    val db = Room.databaseBuilder(view.context,favdatabase::class.java,"dbhelper").allowMainThreadQueries().fallbackToDestructiveMigration().build()
                    val dao =db.favdao()
                    val list = mutableListOf<resdata>()
                    for (i in 0 .. (childarray.length()-1)){
                        val id =childarray.getJSONObject(i).getString("id")
                        val name =childarray.getJSONObject(i).getString("name")
                        val rating =childarray.getJSONObject(i).getString("rating").toFloat()
                        val cost_for_one=childarray.getJSONObject(i).getString("cost_for_one").toInt()
                        val image_url =childarray.getJSONObject(i).getString("image_url")
                        if (dao.checkExists(it.getJSONObject("data").getJSONArray("data").getJSONObject(i).getString("name"))){
                        listRestrurant.add(childarray.getJSONObject(i))
                        val newobj:resdata = resdata(id,name,rating,cost_for_one,image_url)
                        list.add(newobj)}
                    }

                    Toast.makeText(view.context,"Ok",Toast.LENGTH_SHORT).show()
                    recyclerHome = view.findViewById(R.id.recyclerfav)
                    layoutmanager = LinearLayoutManager(activity)
                    adaptorrest = AdaptorHome(activity as Context,list)
                    recyclerHome.adapter = adaptorrest
                    recyclerHome.layoutManager=layoutmanager
                }else{
                    Toast.makeText(view.context,"Not OkL",Toast.LENGTH_SHORT).show()
                }

            }, Response.ErrorListener { Toast.makeText(view.context,"$it",Toast.LENGTH_SHORT).show() }){
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String,String>()
                    headers["Content-Type"]= "application/json"
                    headers["token"] = "93ff4ed315f7e3"
                    return headers
                }
            }
            queue.add(jasonreq)
        }
        else{
            Toast.makeText(view.context,"Not Connected", Toast.LENGTH_LONG).show()
        }
        return view
    }
}