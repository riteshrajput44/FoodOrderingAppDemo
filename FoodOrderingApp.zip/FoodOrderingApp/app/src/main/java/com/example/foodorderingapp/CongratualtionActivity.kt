package com.example.foodorderingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.foodorderingapp.databinding.ActivityCongratualtionBinding

class CongratualtionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityCongratualtionBinding.inflate(layoutInflater)
        val view:View = binding.root
        setContentView(view)

        binding.buttonorderhis.setOnClickListener {
            val inti = Intent(this,MainPage::class.java)
            startActivity(inti)
            finish()
        }
    }
}