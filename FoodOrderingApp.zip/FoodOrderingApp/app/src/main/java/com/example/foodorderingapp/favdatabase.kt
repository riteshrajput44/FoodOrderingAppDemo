package com.example.foodorderingapp

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [dbhelper::class], version = 1)
abstract class favdatabase:RoomDatabase() {
    abstract fun favdao():dao
}