package com.example.foodorderingapp

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONArray
import org.json.JSONObject


class HomeFragment : Fragment() {
    lateinit var recyclerHome: RecyclerView
    lateinit var layoutmanager: RecyclerView.LayoutManager
    lateinit var listRestrurant: ArrayList<JSONObject>
    lateinit var adaptorrest: AdaptorHome
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view: View = inflater.inflate(R.layout.fragment_home, container, false)

        val network = NetworkManager()
        val net = network.checkConnectivity(view.context)

        if (net) {
            setHasOptionsMenu(true)
            val queue = Volley.newRequestQueue(activity as Context)
            val url = "http://13.235.250.119/v2/restaurants/fetch_result/"
            val jasonreq = object : JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                Response.Listener {
                    if (it.getJSONObject("data").getBoolean("success")) {
                        val childarray: JSONArray = it.getJSONObject("data").getJSONArray("data")
                        var list = mutableListOf<resdata>()
                        for (i in 0..(childarray.length() - 1)) {
                            val id = childarray.getJSONObject(i).getString("id")
                            val name = childarray.getJSONObject(i).getString("name")
                            val rating = childarray.getJSONObject(i).getString("rating").toFloat()
                            val cost_for_one =
                                childarray.getJSONObject(i).getString("cost_for_one").toInt()
                            val image_url = childarray.getJSONObject(i).getString("image_url")
                            val newobj: resdata = resdata(id, name, rating, cost_for_one, image_url)
                            list.add(newobj)
                        }
                        val pref: SharedPreferences = container!!.context.getSharedPreferences(
                            "sort",
                            AppCompatActivity.MODE_PRIVATE
                        )

                        when (pref.getInt("state", 0)) {
                            0 -> {
                            }
                            1 -> {
                                list.sortByDescending { it.rating }
                            }
                            2 -> {
                                list.sortBy { it.rating }

                            }
                            3 -> {
                                list.sortByDescending { it.cost_for_one }
                            }
                            4 -> {
                                list.sortBy { it.cost_for_one }

                            }
                        }
                        recyclerHome = view.findViewById(R.id.homerecycle)
                        layoutmanager = LinearLayoutManager(activity)
                        adaptorrest = AdaptorHome(view.context, list)
                        recyclerHome.adapter = adaptorrest
                        recyclerHome.layoutManager = layoutmanager
                        pref.edit().clear().apply()
                    } else {
                        Toast.makeText(view.context, "Not OkL", Toast.LENGTH_SHORT).show()
                    }

                },
                Response.ErrorListener {
                    Toast.makeText(view.context, "$it", Toast.LENGTH_SHORT).show()
                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    headers["token"] = "93ff4ed315f7e3"
                    return headers
                }
            }
            queue.add(jasonreq)
        } else {
            Toast.makeText(view.context, "Not Connected", Toast.LENGTH_LONG).show()
        }

        return view
    }


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.actionbar, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }
}
