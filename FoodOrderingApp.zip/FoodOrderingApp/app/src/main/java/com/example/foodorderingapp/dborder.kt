package com.example.foodorderingapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dnorder")
data class dborder (
    @PrimaryKey val id:String,
    val cost:String,
    val res_id:String,
    val name:String
        )