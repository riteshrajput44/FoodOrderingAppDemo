package com.example.foodorderingapp

import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.R
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONArray
import org.json.JSONObject


class OrderHistoryFragment : Fragment() {
    lateinit var recyclerOrderhis: RecyclerView
    lateinit var layoutmanager: RecyclerView.LayoutManager
    lateinit var adaptororder: AdaptorParentOrder
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_order_history, container, false)
        val network = NetworkManager()
        val net = network.checkConnectivity(view.context)
        if (net) {
            val pref:SharedPreferences = container!!.context.getSharedPreferences("login",
                AppCompatActivity.MODE_PRIVATE
            )
            val id = pref.getString("user_id","")
            val url = "http://13.235.250.119/v2/orders/fetch_result/${id}"
            val queue = Volley.newRequestQueue(view.context)
            val jsonreq = object : JsonObjectRequest(
                Request.Method.GET,
                url,

                null,
                Response.Listener {
                    if (it.getJSONObject("data").getBoolean("success")) {
                        recyclerOrderhis = view.findViewById(R.id.rv_order_parent)
                        layoutmanager = LinearLayoutManager(activity)
                        adaptororder = AdaptorParentOrder(
                            view.context,
                            it.getJSONObject("data").getJSONArray("data")
                        )
                        recyclerOrderhis.adapter = adaptororder
                        recyclerOrderhis.layoutManager = layoutmanager
                    }
                    else{Toast.makeText(view.context,"why",Toast.LENGTH_SHORT).show()}
                },
                Response.ErrorListener { }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    headers["token"] = "93ff4ed315f7e3"
                    return headers
                }
            }
            queue.add(jsonreq)
        } else {
            Toast.makeText(view.context, "Check connection", Toast.LENGTH_SHORT).show()
        }

        return view
    }


}