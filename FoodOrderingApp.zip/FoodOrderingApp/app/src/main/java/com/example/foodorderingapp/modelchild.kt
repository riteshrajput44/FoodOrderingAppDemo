package com.example.foodorderingapp

class modelchild(val name:String,val cost:String)