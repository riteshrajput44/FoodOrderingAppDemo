package com.example.foodorderingapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName  ="dbhelper")
data class dbhelper (
    @PrimaryKey val name:String
        )