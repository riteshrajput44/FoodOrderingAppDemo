package com.example.foodorderingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.example.foodorderingapp.databinding.ActivityForgotPwdBinding
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONObject

class ForgotPwdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val network = NetworkManager()
        val net = network.checkConnectivity(this)
        val binding: ActivityForgotPwdBinding = ActivityForgotPwdBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        binding.gologinchangepwd.setOnClickListener {
            if (net) {
                val inti = Intent(this, LoginActivity::class.java)
                startActivity(inti)
                finish()
            } else {
                Toast.makeText(this, "Check Network", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnchangeowd.setOnClickListener {
            if (net) {
                val url = "http://13.235.250.119/v2/forgot_password/fetch_result"
                val jasonObj = JSONObject()
                jasonObj.put("mobile_number", binding.emailnewpwd.text.toString())
                jasonObj.put("email", binding.newpwd.text.toString())
                if (binding.emailnewpwd.text.toString().length == 10) {
                    val jasonquery = object : JsonObjectRequest(Request.Method.POST, url, jasonObj,
                        Response.Listener {
                            try {
                                val success = it.getJSONObject("data").getBoolean("success")
                                if (success) {
                                    val inti = Intent(this, ChangePassword::class.java)
                                    startActivity(inti)
                                    finish()
                                } else {
                                }
                            } catch (e: Exception) {
                            }
                        }, Response.ErrorListener { }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Content-Type"] = "application/json"
                            headers["token"] = "93ff4ed315f7e3"
                            return headers
                        }
                    }
                }
            }else{
                Toast.makeText(this, "Check Network", Toast.LENGTH_SHORT).show()
            }
        }
    }
}