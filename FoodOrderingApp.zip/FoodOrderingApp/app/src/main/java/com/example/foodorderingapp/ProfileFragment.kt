package com.example.foodorderingapp

import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.foodorderingapp.R
import com.example.foodorderingapp.util.NetworkManager


class ProfileFragment : Fragment() {

    lateinit var name:TextView
    lateinit var email:TextView
    lateinit var address:TextView
    lateinit var mobile:TextView
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view:View= inflater.inflate(R.layout.fragment_profile, container, false)
        name = view.findViewById(R.id.nameprofile)
        email = view.findViewById(R.id.emailprofile)
        address = view.findViewById(R.id.addressprofile)
        mobile = view.findViewById(R.id.phonenumberprofile)
        val network = NetworkManager()
        val net = network.checkConnectivity(view.context)
        if(net){
            val pref:SharedPreferences = container!!.context.getSharedPreferences("login",
                AppCompatActivity.MODE_PRIVATE
            )
            if (pref.contains("user_id")){
                name.text = pref.getString("name","")
                email.text = pref.getString("email","")
                address.text = pref.getString("address","")
                mobile.text=pref.getString("mobile_number","")
            }
        }
        else{
            Toast.makeText(view.context,"Not Connceted Error!",Toast.LENGTH_SHORT).show()
        }
        return view
    }

}