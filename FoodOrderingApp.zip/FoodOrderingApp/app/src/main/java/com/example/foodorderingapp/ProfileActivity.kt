package com.example.foodorderingapp

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.foodorderingapp.databinding.ActivityProfileBinding
import com.example.foodorderingapp.util.NetworkManager

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityProfileBinding.inflate(layoutInflater)
        val view:View = binding.root
        val network = NetworkManager()
        val net = network.checkConnectivity(this)
        val pref:SharedPreferences = getSharedPreferences("login", MODE_PRIVATE)
        setContentView(view)
        binding.emailprofile.text = pref.getString("email","")
        binding.addressprofile.text=pref.getString("address","")
        binding.nameprofile.text=pref.getString("name","")
        binding.phonenumberprofile.text=pref.getString("mobile_number","")
    }
}