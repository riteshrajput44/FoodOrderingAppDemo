package com.example.foodorderingapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject

class AdaptorOrderNow(val context: Context,val orderlist: ArrayList<List<String>>):RecyclerView.Adapter<AdaptorOrderNow.MyHolder>() {
    class MyHolder(view: View):RecyclerView.ViewHolder(view){
        val name:TextView=view.findViewById(R.id.dishnameorder)
        val cost:TextView = view.findViewById(R.id.costitemorder)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.orderview,parent,false)
        return MyHolder(view)
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        holder.name.text = orderlist[position][3]
        holder.cost.text = orderlist[position][1]
    }

    override fun getItemCount(): Int {
        return orderlist.size
    }
}