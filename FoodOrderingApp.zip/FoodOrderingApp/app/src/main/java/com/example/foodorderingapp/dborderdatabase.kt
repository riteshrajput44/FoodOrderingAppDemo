package com.example.foodorderingapp

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [dborder::class], version = 1)
abstract class dborderdatabase:RoomDatabase() {
    abstract fun orderDao():orderdao
}