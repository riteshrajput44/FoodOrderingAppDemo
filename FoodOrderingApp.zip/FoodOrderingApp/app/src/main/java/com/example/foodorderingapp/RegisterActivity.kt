package com.example.foodorderingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.room.Dao
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Request.Method.POST
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.foodorderingapp.databinding.ActivityRegisterBinding
import com.example.foodorderingapp.util.NetworkManager
import org.json.JSONArray
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding:ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        val view = binding.root
        val network = NetworkManager()
        val net = network.checkConnectivity(this)

        setContentView(view)
        binding.regbtnlogin.setOnClickListener{if (net){
            val inti =Intent(this,LoginActivity::class.java)
            startActivity(inti)
            finish()}else{Toast.makeText(this,"Check Network",Toast.LENGTH_SHORT).show()}
        }
        binding.regbtnforgotpwd.setOnClickListener {if(net){ val inti =Intent(this,ForgotPwdActivity::class.java)
        startActivity(inti)
        finish()}else{Toast.makeText(this,"Check Network",Toast.LENGTH_SHORT).show()}}

        binding.regbtnregister.setOnClickListener {if(net){
            val queue = Volley.newRequestQueue(this)
            val url = "http://13.235.250.119/v2/register/fetch_result"
            val jasonParams = JSONObject()
            jasonParams.put("name",binding.regnameedit.text.toString())
            jasonParams.put("mobile_number",binding.regmobiledit.text.toString())
            jasonParams.put("password",binding.regpassedit.text.toString())
            jasonParams.put("address", binding.editredaddrest.text.toString())
            jasonParams.put("email",binding.regemailedit.text.toString())
            println(jasonParams)
            val jasonRequest = object :
                JsonObjectRequest(Request.Method.POST,url,jasonParams, Response.Listener {
                    try {
                        val regJsonObject = it.getJSONObject("data").getBoolean("success")
                        if (regJsonObject){
                            Toast.makeText(this,"ok done",Toast.LENGTH_SHORT).show()
                            val inti = Intent(this,LoginActivity::class.java)
                            startActivity(inti)
                            finish()
                        }
                        else{
                            Toast.makeText(this,"Failed",Toast.LENGTH_SHORT).show()
                        }
                    }catch (e:Exception){
                        Toast.makeText(this,"Y $it",Toast.LENGTH_SHORT).show()
                        println(it)
                    }
                }, Response.ErrorListener {
                    Toast.makeText(this,"$it",Toast.LENGTH_LONG).show()
                }){
                override fun getHeaders(): MutableMap<String, String> {
                    val headers =HashMap<String,String>()
                    headers["Content-Type"]= "application/json"
                    headers["token"] = "93ff4ed315f7e3"
                    return headers
                }
            }
            queue.add(jasonRequest)

        }else{Toast.makeText(this,"Check Network",Toast.LENGTH_SHORT).show()}
        }
    }
}